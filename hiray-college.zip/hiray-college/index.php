<?php
require_once 'vendor/autoload.php';
define("MAIL_HOST", "smtp.gmail.com");
//define("MAIL_USERNAME", "kubic.testing2@gmail.com");
//define("MAIL_PASSWORD", "xdzulkzxuzwqtlkd");
define("MAIL_USERNAME", "noreply.hiraycollege@gmail.com");
define("MAIL_PASSWORD", "gupehqnlunmzquvs");
define("MAIL_PORT", "587");
$error = false;
$errorMessage = '';
// $success = false;
$successMessage = "";

function sendMailSwift($to_email, $to_name, $subject, $message)
{

    // Create the Transport
    $transport = (new Swift_SmtpTransport(MAIL_HOST, MAIL_PORT))
        ->setUsername(MAIL_USERNAME)
        ->setPassword(MAIL_PASSWORD)->setEncryption('tls');

    // Create the Mailer using your created Transport
    $mailer = new Swift_Mailer($transport);

    // Create a message
    $message = (new Swift_Message($subject))
        ->setFrom([MAIL_USERNAME => MAIL_USERNAME])
        ->setTo([$to_email => $to_name])
        ->setBody($message);
    $message->setContentType("text/html");

    // Send the message
    $result = $mailer->send($message);
    return $result;
}



if (isset($_POST['send_msg'])) {
    // echo 'hii';
    // die();
    $name = '';
    $email = '';
    $subject = '';
    $message = '';

    if (isset($_POST['name']) && $_POST['name'] != '') {
        $name = $_POST['name'];
    } else {
        $error = true;
        $errorMessage .= 'Please enter name<br>';
    }
    if (isset($_POST['email']) && $_POST['email'] != '') {
        $email = $_POST['email'];
    } else {
        $error = true;
        $errorMessage .= 'Please enter email <br>';
    }
    if (isset($_POST['subject']) && $_POST['subject'] != '') {
        $subject = $_POST['subject'];
    } else {
        $error = true;
        $errorMessage .= 'Please enter subject<br>';
    }
    if (isset($_POST['message']) && $_POST['message'] != '') {
        $message = $_POST['message'];
    } else {
        $error = true;
        $errorMessage .= 'Please enter message<br>';
    }

    // echo $name . '<br>';
    // echo $email . '<br>';
    // echo $subject . '<br>';
    // echo $message . '<br>';
    // die();



    if (!$error) {
        $msg = "<table>
<tr>
<td>Name :</td>
<td>$name</td>
</tr>
<tr>
<td>Email Address :</td>
<td>$email</td>
</tr>
<tr>
<td>Subject :</td>
<td>$subject</td>
</tr>
<tr>
<td>Message :</td>
<td>$message</td>
</tr>
</table>";
        // print_r($msg);
        // die();
        $toName = "HIRAY COLLEGE";
        // $toEmail = "info@hiray.edu.in";
        $toEmail = "ajeet.kumar@kubictechnology.in";
        $send_email = sendMailSwift($toEmail, $toName, "Enquiry from Website", $msg);
        if ($send_email) {
            $success = true;
            // $successMessage .= "Thank you for your Message, We will get back to you";
        } else {
            $error = true;
            $errorMessage .= "Issue while sending email Please try after some time.<br>";
        }
    }
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <!-- <title>HIRAY GROUP OF INSTITUTES
    L.B.H.S.S.TRUST’S INSTITUTE OF DESIGN</title> -->
    <Title>Hiray Group Of Institute L.B.H.S.S. Trust's Institute Of Design</Title>
    <meta name="description"
        content="In the metropolitan of Mumbai, there is a vast demand for specialized and trained INTERIOR DESIGNERS and INTERIOR DECORATORS. Other institutes presently offering education in Interior Designing and Decoration much less fulfill this demand. In fact, all the latest trends of design in this country have originated from Mumbai and such city has a vast potential for formal training in this intricate field of INTERIOR ENVIRONMENT DESIGNING.">
    <meta name="keywords"
        content="Hiray School of Design, Bhausaheb Hiray S.S. Trust, education, Maharashtra, interior design, Degree course, Advanced Diploma course, teaching methods, individuality, goal-oriented attitude, global market demand">
    <meta property="og:title" content="Hiray Group Of Institute L.B.H.S.S. Trust's Institute Of Design">
    <meta property="og:description"
        content="In the metropolitan of Mumbai, there is a vast demand for specialized and trained INTERIOR DESIGNERS and INTERIOR DECORATORS. Other institutes presently offering education in Interior Designing and Decoration much less fulfill this demand. In fact, all the latest trends of design in this country have originated from Mumbai and such city has a vast potential for formal training in this intricate field of INTERIOR ENVIRONMENT DESIGNING.">
    <meta property="og:image" content="http://hiraycaisdm.co.in/assets/img/logo-img.png">
    <meta property="og:url" content="http://hiraycaisdm.co.in/assets/img/logo-img.png">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="Hiray Group Of Institute L.B.H.S.S. Trust's Institute Of Design">
    <meta name="twitter:description"
        content="In the metropolitan of Mumbai, there is a vast demand for specialized and trained INTERIOR DESIGNERS and INTERIOR DECORATORS. Other institutes presently offering education in Interior Designing and Decoration much less fulfill this demand. In fact, all the latest trends of design in this country have originated from Mumbai and such city has a vast potential for formal training in this intricate field of INTERIOR ENVIRONMENT DESIGNING.">
    <meta name="twitter:image" content="http://hiraycaisdm.co.in/assets/img/logo-img.png">

    <!-- Favicons -->
    <!-- assets\img\logo-white.png -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">

</head>

<body>

    <script>

    </script>

    <!-- ======= Header ======= -->

    <header id="header" class="header fixed-top menu-section">
        <div class="container-fluid container-xl d-flex align-items-center justify-content-between ">

            <a href="index.php" class="logo d-flex align-items-center">
                <div class="logo-div">
                    <img src="assets/img/logo-img.png" alt="">
                </div>
                <span>Hiray CAISDM</span>
            </a>
            <nav id="navbar" class="navbar">
                <ul>
                    <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
                    <li><a class="nav-link scrollto" href="#about">About</a></li>
                    <li><a class="nav-link scrollto" href="#courses">Courses</a></li>
                    <li><a class="nav-link scrollto" href="#structure">Structure of courses</a></li>
                    <li><a class="nav-link scrollto" href="#team">Team</a></li>
                    <!-- <li><a class="nav-link scrollto" href="#contact">Contact</a></li> -->
                    <li><a class="getstarted scrollto" href="#contact">Contact Us</a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav>
            <!-- .navbar -->

        </div>
    </header>
    <!-- End Header -->

    <!-- ======= Hero Section ======= -->
    <section id="hero" class="hero d-flex align-items-center">
        <div class="container-fluid" style="padding: 0px;">
            <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active"
                        aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1"
                        aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2"
                        aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                    <div id="overlay" class="carousel-item active" data-bs-interval="10000">
                        <img src="assets/img/slider/slider-1.png" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">

                            <h4>HIRAY GROUP OF INSTITUTES
                                L.B.H.S.S.TRUST’S INSTITUTE OF DESIGN</h4>
                        </div>
                    </div>
                    <div id="overlay" class="carousel-item" data-bs-interval="2000">
                        <img src="assets/img/slider/slider-2.png" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <!-- <h5>Second slide label</h5> -->
                            <h4>HIRAY GROUP OF INSTITUTES
                                L.B.H.S.S.TRUST’S INSTITUTE OF DESIGN</h4>
                        </div>
                    </div>
                    <div id="overlay" class="carousel-item">
                        <img src="assets/img/slider/slider-3.png" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <!-- <h5>Third slide label</h5> -->
                            <h4>HIRAY GROUP OF INSTITUTES
                                L.B.H.S.S.TRUST’S INSTITUTE OF DESIGN</h4>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>



    </section>
    <!-- End Hero -->

    <main id="main">
        <!-- ======= About Section ======= -->
        <section id="about" class="about">
            <div class="container about-container" data-aos="fade-up">
                <div class="row new-row">
                    <h2 class="about-heading">ABOUT THE COURSES </h2>
                    <div class="col-lg-7 col-md-7 col-xs-12" data-aos="fade-up" data-aos-delay="200">
                        <!-- <div class="content" style="padding: 18px;"> -->
                        <p>
                            In the metropolitan of Mumbai, there is a vast demand for specialized and trained <strong>
                                INTERIOR
                                DESIGNERS </strong> and
                            <strong>INTERIOR DECORATORS</strong>. Other institutes presently offering education in
                            Interior Designing
                            and Decoration
                            much less fulfill this demand. In fact, all the latest trends of design in this country have
                            originated
                            from Mumbai and such a city has a vast potential for formal training in this intricate field
                            of
                            <strong>INTERIOR
                                ENVIRONMENT DESIGNING</strong>.
                        </p>
                        <p>Keeping this in mind in 1997, Late Bhausaheb Hiray Smarnika Samiti Trust set up the
                            <strong>“INSTITUTE OF
                                DESIGN”</strong> on Plot No. 341, Next to New English School, Bandra (East), Mumbai 400
                            051. This area
                            of Bandra
                            is yet undergoing major development and is also convenient for students from South Mumbai
                            and Suburban
                            Mumbai, an institute of design offering Certificate and Diploma Courses in Computer Aided
                            Interior Space
                            Design and Management, is ideally located.

                        </p>
                        <p>It is not yet finally decided but The Interior Design Department would want to broaden its
                            arena
                            to
                            impart education through socially required (Part-Time) short-term special courses namely;
                        <ul class="about-ul">
                            <li> Certificate in <strong>PERSONALITY ENHANCEMENT & COMMUNICATION SKILLS</strong> (30
                                Hours)
                            </li>
                            <li> Diploma in <strong>SET DESIGN</strong> (60 Hours)</li>
                        </ul>
                        </p>
                        <!-- </div> -->
                    </div>
                    <div class="col-lg-5 col-md-5 col-xs-12" data-aos="zoom-out" data-aos-delay="200">
                        <img src="assets/img/college-builing.jpg" class="img-thumbnail" alt="" style="margin-top: 3%;">
                        <div class=" mt-3">
                            <p>The motto of the Interior Design Department is – <strong>“OUR PASSOUTS</strong> must be
                                <strong>MORE
                                    PRACTICAL ORIENTED</strong> (not
                                only poetic) to serve the society in a very <strong>NOBLE WAY</strong>.
                            </p>
                        </div>
                        <div class="text-center mentor-name">
                            <div class="metor-image">
                                <img src="assets/img/team/pranav.png" class="img-thumbnail" alt=""><br>
                            </div>
                            <div class="mentor-name">
                                <span>Ar. PRANAV BHATT</span>
                                <p>(Mentor)</p>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </section>

        <!-- End About Section -->

        <!-- <section class="mentor-section">
            <div class="container" id="metor-section" data-aos="fade-up">
                <div class="row ">
                    <div class="col-lg-12 col-md-12 col-xs-12" data-aos="fade-up" data-aos-delay="200">
                        <div class="mentor-content">
                            <p>The motto of the Interior Design Department is – <strong>“OUR PASSOUTS</strong> must be
                                <strong>MORE
                                    PRACTICAL ORIENTED</strong> (not
                                only poetic) to serve the society in a very <strong>NOBLE WAY</strong>.
                            </p>
                        </div>
                        <div class="text-center mentor-name">
                            <div class="metor-image">
                                <img src="assets/img/team/shanmu.jpg" class="img-thumbnail" alt=""><br>
                            </div>
                            <div class="mentor-name">
                                <span>Ar. PRANAV BHATT<br></span>
                                <p>(Mentor)
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- ======= About Section ======= -->
        <section id="" class="mentor-section">
            <div class="container" data-aos="fade-up">
                <div class="row new-row">
                    <h2 class="about-heading">INTERIOR CORNER</h2>
                    <div class="col-lg-7 col-md-7 col-xs-12" data-aos="fade-up" data-aos-delay="200">
                        <!-- <div class="content" style="padding: 18px;"> -->
                        <p>
                            While the world has moved on such, that he/she can have a choice about everything, from how
                            he/she likes
                            their tea/coffee to how they personalize their bikes in megacities like Mumbai. On the other
                            hand,
                            scientifically and ergonomically considered and evaluated Interior / Exterior Space design
                            has still to
                            catch up.
                        </p>
                        <p>In my opinion, one must not forget while designing any environmental spaces (Exterior or
                            Interior)
                            either in smart city or Green architecture or Spaces Environment, to have a main basic
                            CONCEPT (idea) of
                            providing and /or furnishing environmental Space Design for various activity performances
                            along with
                            consideration of safety, desired comfort etc to user/users. This is because professions of
                            Architecture
                            and Interior Designing also, are covered under the <strong>“CONSUMER PROTECTION
                                ACT”</strong>.

                        </p>
                        <p>Hence, while imparting education on the students of Interior Design course, it is essential
                            that
                            teachers should stress on the students that Interior Design proposals / assignments should
                            be such that
                            it should not cause any physical/mental problem to the users </p>
                        <!-- </div> -->
                    </div>
                    <div class="col-lg-5 col-md-5 col-xs-12 interior-image" data-aos="zoom-out" data-aos-delay="200">
                        <img src="assets/img/about.jpg" class="img-thumbnail" alt="" style="margin-top: 8%;">
                    </div>

                    <p>and it should create appropriate for our Senior Students of Interior Design Department to
                        organize
                        <strong>FRESHERS
                            PARTY </strong> for First Year (new entrants) students creating a very pleasing
                        intermingling
                        introductory
                        atmosphere so that new entrants willingly become part of the Interior Design Department Family.
                        e
                        mood to
                        perform the respective required activities with desired comfort, safety, and ease of maintenance
                        in
                        respective designed spaces. <br>Keeping in mind the above and our suggestions and request with
                        reasoning, our teachers give more thrust on the ergonomically aspects to design along with
                        usability
                        (function) with desired comfort than the looks (aesthetics) only.
                    </p>

                    <!-- <div class="col-lg-12 col-md-12 col-xs-12" data-aos="fade-up" data-aos-delay="200"> -->
                    <div class="mentor-content">
                        <p>Students in our institute learn and are educated in all the basic and specialized
                            aspects of
                            related subjects.<br>
                            To conclude, I take this opportunity to wish, wholeheartedly all the students to BE
                            <strong>SUCCESSFUL
                                AND
                                ACHIEVE ALL THE BEST IN LIFE</strong>.
                        </p>
                    </div>
                    <div class="text-center">
                        <div class="metor-image ">
                            <img src="assets/img/team/pratiksha.png" class="img-thumbnail" alt=""><br>
                        </div>
                        <div class="mentor-name">
                            <span>Mrs.PRATIKSHA RAVAL <br></span>
                            <p>Head of Department, <br>
                                (Interior Design Deptt.)
                            </p>
                        </div>

                    </div>
                    <!-- </div> -->
                    <div>
                        <h2 class="about-heading">Under listed are Various Extra Curricular Activities for students of
                            the Interior
                            Department:</h2>


                        <div class="row" style="padding-bottom: 30px;">
                            <div class="col-lg-6">
                                <div class="accordion accordion-flush" id="faqlist1">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                                                FRESHERS PARTY
                                            </button>
                                        </h2>
                                        <div id="faq-content-1" class="accordion-collapse collapse"
                                            data-bs-parent="#faqlist1">
                                            <div class="accordion-body">
                                                <p>Our Senior Students of the Interior Design Department organize
                                                    <strong>FRESHERS PARTY</strong> for First Year (new entrants)
                                                    students creating a very pleasing
                                                    intermingling
                                                    introductory atmosphere so that new entrants willingly become part
                                                    of the Interior Design
                                                    Department
                                                    Family.
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                                                NAVRATRI
                                            </button>
                                        </h2>
                                        <div id="faq-content-2" class="accordion-collapse collapse"
                                            data-bs-parent="#faqlist1">
                                            <div class="accordion-body">
                                                <p>One of the evenings during <strong>NAVRATRI</strong> days, the
                                                    students
                                                    celebrate by
                                                    organizing <strong>GARBA / RAAS & perform AARTI </strong>praying
                                                    Goddess to prevail upon the
                                                    best to
                                                    live
                                                    in.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                                                STUDY TOUR
                                            </button>
                                        </h2>
                                        <div id="faq-content-3" class="accordion-collapse collapse"
                                            data-bs-parent="#faqlist1">
                                            <div class="accordion-body">
                                                <p>STUDY TOUR of 8 to 10 days is generally scheduled during November /
                                                    December month for Interior Design Department students, to get
                                                    broader exposure and there the
                                                    students
                                                    are taught the method and manner of measuring interior spaces and
                                                    furniture. They are asked to
                                                    submit
                                                    in (formed) groups, the <strong>MEASURED DRAWINGS</strong> of the
                                                    interior spaces measured
                                                    during
                                                    the
                                                    study tour, on
                                                    return, submitted drawings are assessed, appreciated, and exhibited.
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq-content-4">
                                                TARASH
                                            </button>
                                        </h2>
                                        <div id="faq-content-4" class="accordion-collapse collapse"
                                            data-bs-parent="#faqlist1">
                                            <div class="accordion-body">
                                                <p>Our Annual Event (of three or four days) – TARASH, generally
                                                    scheduled in the last week of January every year. This is to evolve
                                                    an appreciable approach to various themes every year. This event
                                                    comprises of Intercollegiate Interior Design competition, Intra
                                                    college's Annual term work Exhibition, On Spot Competitions, and
                                                    Cultural Programmes (Singing, Dancing, Fashion show, etc.) during
                                                    this period, Not only our students participate, but as Fragrance and
                                                    Flavour have spread to the students of Other Colleges / Institutes,
                                                    so – they also participate, mingle and enjoy.
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="accordion accordion-flush" id="faqlist2">


                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq2-content-2">
                                                SITE VISIT
                                            </button>
                                        </h2>
                                        <div id="faq2-content-2" class="accordion-collapse collapse"
                                            data-bs-parent="#faqlist2">
                                            <div class="accordion-body">
                                                <p>Site visits are conducted of modular furniture manufacturing
                                                    factories, other interior material manufacturing factories,
                                                    furniture showrooms, sites during work in progress, Existing
                                                    Auditoriums, Hospitals, etc. for students to observe the
                                                    circulation, environment feeling, provision of specialized services,
                                                    and interview the people working in these spaces.
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq2-content-3">
                                                SEND OFF EVENT
                                            </button>
                                        </h2>
                                        <div id="faq2-content-3" class="accordion-collapse collapse"
                                            data-bs-parent="#faqlist2">
                                            <div class="accordion-body">
                                                <p>In the month of April, our Juniors organize SEND OFF event to wish
                                                    all the senior students (Final Year Students), the BEST OF LUCK in
                                                    making their career in the Interior Design Profession.</p>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq2-content-4">
                                                SEMINAR / WORKSHOP
                                            </button>
                                        </h2>
                                        <div id="faq2-content-4" class="accordion-collapse collapse"
                                            data-bs-parent="#faqlist2">
                                            <div class="accordion-body">
                                                <p>Experts are invited to enlighten and make aware the students of
                                                    various specialized subjects and topics, equipment, etc.
                                                </p>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>




                        </div>

                        <!-- </div> -->
                        <!-- <ul>
            <li><span><b>FRESHERS PARTY :</b></span>Our Senior Students of Interior Design Department organize
              <strong>FRESHERS PARTY</strong> for First Year (new entrants) students creating very pleasing
              intermingling
              introductory atmosphere so that new entrants willingly become part of the Interior Design Department
              Family.
            </li>
            <li><span><b> NAVRATRI :</b></span>One of the evenings during <strong>NAVRATRI</strong> days, the students
              celebrate by
              organising <strong>GARBA / RAAS & perform AARTI </strong>praying Goddess to prevail upon the best to live
              in. </li>
          </ul>
          <ul>
            <li><span><b>STUDY TOUR :</b></span>STUDY TOUR of 8 to 10 days is generally scheduled during November /
              December month for Interior Design Department students, to get broader exposure and there the students
              are taught the method and manner of measuring interior spaces and furniture. They are asked to submit
              in (formed) groups, the <strong>MEASURED DRAWINGS</strong> of the interior spaces measured during the
              study tour, on
              return, submitted drawings are assessed, appreciated and exhibited.</li>
            <li><span><b>TARASH :</b></span>: Our Annual Event (of three or four days) – TARASH, generally scheduled
              in last week of January every year. This is to evolve appreciable approach on various themes every
              year. This event comprises of Inter collegiate Interior Design competition, Intra college Annual term
              work Exhibition, On the Spot Competitions, Cultural Programmes (Singing, Dancing, Fashion show etc.)
              during this period, Not only our students participate, but as it’s Fragrance and Flavour has spreaded
              to the students of Other Colleges / Institutes, so – they also participate, mingle and enjoy.</li>
            <li><span><b>SITE VISIT :</b></span>Site visits are conducted of modular furniture manufacturing
              factories, other interior material manufacturing factories, furniture showrooms, site during work in
              progress, Existing Auditoriums, Hospitals etc. for students to observe the circulation, environment
              feeling, provision of specialized services and interviewing the people working in this spaces. </li>
            <li><span><b>SEND OFF EVENT :</b></span>In the month of April, our Juniors organize SEND OFF event to
              wish all the senior most students (Final Year Students), the BEST OF LUCK in making their career in
              the Interior Design Profession.</li>
            <li><span><b>SEMINAR / WORKSHOP :</b></span>Experts are invited to enlighten and to make aware the
              students on various specialised subjects and topics, equipments etc.
            </li>
          </ul> -->

                    </div>
                </div>

        </section>
        <!-- <section class="mentor-section">
            <div class="container" id="metor-section" data-aos="fade-up">
                <div class="row ">
                    <div class="col-lg-12 col-md-12 col-xs-12" data-aos="fade-up" data-aos-delay="200">
                        <div class="mentor-content">
                            <p>Students in our institute learn and are educated with all the basic and specialised
                                aspects of
                                related subjects.<br>
                                To conclude, I take this opportunity to wish, whole-heartedly all the students to BE
                                <strong>SUCCESSFUL
                                    AND
                                    ACHIEVE ALL THE BEST IN LIFE</strong>.
                            </p>
                        </div>
                        <div class="text-center">
                            <div class="metor-image ">
                                <img src="assets/img/team/prajakta.jpg" class="img-thumbnail" alt=""><br>
                            </div>
                            <div class="mentor-name">
                                <span>Mrs.PRATIKSHA RAVAL <br></span>
                                <p>Head of Department, <br>
                                    (Interior Design Deptt.)
                                </p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section> -->

        <section id="services" class="services">
            <div class="container" data-aos="fade-up">
                <div class="services-row">
                    <h2 class="about-heading">PHILOSOPHY OF EDUCATION OF OUR COURSES</h2>
                    <div class="row mt-5 mb-5">
                        <div class="col-lg-4 col-md-6 col-xs-12" data-aos="fade-up" data-aos-delay="200">
                            <div class="service-box blue">
                                <i class="ri-discuss-line icon"></i>
                                <h3>FREEDOM</h3>
                                <p> Freedom of TRUTH, freedom from SUPERSTITIONS and freedom from BLIND FAITH. </p>
                                <!-- <a href="#" class="read-more"><span>Read More</span> <i class="bi bi-arrow-right"></i></a> -->
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-xs-12" data-aos="fade-up" data-aos-delay="300">
                            <div class="service-box orange">
                                <i class="ri-discuss-line icon"></i>
                                <h3>CREATIVE SELF EXPRESSION</h3>
                                <p>Brings out Creativity and Ability to express oneself without any fear. </p>
                                <!-- <a href="#" class="read-more"><span>Read More</span> <i class="bi bi-arrow-right"></i></a> -->
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-xs-12" data-aos="fade-up" data-aos-delay="400">
                            <div class="service-box green">
                                <i class="ri-discuss-line icon"></i>
                                <h3>ACTIVE COMMUNICATION WITH NATURE & HUMAN BEING</h3>
                                <p>Helps in Active Communication of Human beings and with Nature. </p>
                                <!-- <a href="#" class="read-more"><span>Read More</span> <i class="bi bi-arrow-right"></i></a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>




        <!-- ======= Features Section ======= -->
        <section id="courses" class="features">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <h2>INFORMATION OF COURSES </h2>
                </header>
                <!-- Feature Tabs -->
                <div class="row feture-tabs" data-aos="fade-up">
                    <div class="col-lg-12">
                        <!-- <h3>PHILOSOPHY OF EDUCATION OF OUR COURSES</h3> -->

                        <!-- Tabs -->
                        <ul class="nav nav-pills mb-3">
                            <!-- <li>
                <a class="nav-link active" data-bs-toggle="pill" href="#tab1">Our Courses</a>
              </li> -->
                            <li><a class="nav-link active" data-bs-toggle="pill" href="#tab2">COURSES OFFERED </a> </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab3">JOB OPPORTUNITIES </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab4">HOSTEL FACILITY </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab5">TEACHING AND LEARNING PROCESS
                                </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab6">PLACEMENTS </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab7">FURTHER INFORMATIONS OF COURSES
                                </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab8">Note </a>
                            </li>
                        </ul><!-- End Tabs -->

                        <!-- Tab Content -->
                        <div class="tab-content">

                            <!-- <div class="tab-pane fade show active" id="tab1">

                <div class="d-flex align-items-center mb-2">
                  <i class="bi bi-check2"></i>
                  <h4>FREEDOM</h4>
                </div>
                <p>Freedom of TRUTH, freedom from SUPERSTITIONS and freedom from BLIND FAITH.</p>
                <div class="d-flex align-items-center mb-2">
                  <i class="bi bi-check2"></i>
                  <h4>CREATIVE SELF EXPRESSION</h4>
                </div>
                <p>Brings out Creativity and Ability to express oneself without any fear.</p>

                <div class="d-flex align-items-center mb-2">
                  <i class="bi bi-check2"></i>
                  <h4>ACTIVE COMMUNICATION WITH NATURE & HUMAN BEING:</h4>
                </div>
                <p> Helps in Active Communication of Human beings and with Nature.</p>
              </div> -->

                            <!-- End Tab 1 Content -->

                            <div class="tab-pane fade show active" id="tab2">
                                <h4>The INSTITUTE OF DESIGN (INTERIOR DESIGN DEPARTMENT) awards respective
                                    Certificate/Diploma to those,
                                    who successfully complete the following:</h4>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p>INSTITUTE CERTIFICATE COURSE in COMPUTER AIDED INTERIOR SPACE DESIGN & MANAGEMENT
                                        (One-year
                                        Full-time).</p>
                                </div>

                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p>INSTITUTE DIPLOMA COURSE in COMPUTER AIDED INTERIOR SPACE DESIGN & MANAGEMENT
                                        (Two-year full
                                        time).</p>
                                </div>

                            </div><!-- End Tab 2 Content -->

                            <div class="tab-pane fade show" id="tab3">
                                <p>With the growing population and greater fluency in Indian Society, there is an
                                    acute need for
                                    TRAINED, NOBLE, and PRACTICAL Interior Designers and/or Interior Decorators to
                                    satisfy the design
                                    requirements (needs) of modern Residences and other than Residential Interior Spaces
                                    (such as
                                    commercial, Recreational, Educational, Medical – Health Caring spaces, etc) not only
                                    in Mumbai but
                                    outside Mumbai also</p>
                                <div class="d-flex align-items-center mb-2">
                                    <!-- <i class="bi bi-check2"></i> -->
                                    <h4></h4>
                                </div>
                                <p>For Certificate / Diploma holders in Interior Space Design and Management:
                                    The students undertaking the Institute Diploma Course in Computer Aided Interior
                                    Space Design &
                                    Management would undergo a full-hedged program in studying Interior Space Designing,
                                    Decoration, and
                                    various Management aspects of it. These students would be endowed with the required
                                    understanding,
                                    knowledge & skills and so that they easily may find employment in :
                                <ul>
                                    <li>Architectural firms, </li>
                                    <li> Interior design firms,</li>
                                    <li> Interior Decorating firms, </li>
                                    <li> With a couple of years of experience, they can also find themselves
                                        self-employed.
                                    </li>
                                </ul>
                                </p>

                            </div><!-- End Tab 3 Content -->

                            <div class="tab-pane fade show" id="tab4">


                                <p>The Trust has made Hostel accommodation available, only for the Boys, in its College
                                    building itself.
                                </p>

                            </div><!-- End Tab 1 Content -->


                            <div class="tab-pane fade show" id="tab5">



                                <ul>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p> Classroom lectures / Practical's & discussions.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p>If the need arises, Online Class Lectures/Practical's & discussions.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p> Assignments.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p>Presentations (seminars).</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p> Computer Aided Drawing, Drafting, Designing & Detailing.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p> Interior Design related in-depth/Project study.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p> Case study.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p> Stimulation techniques.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p>Student Interface & field training.</p>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-check2"></i>
                                        <p>Internship</p>
                                    </div>



                            </div><!-- End Tab 1 Content -->

                            <div class="tab-pane fade show" id="tab6">


                                <p><i class="bi bi-check2"></i>The Trust has started ‘PLACEMENT CELL’ and provides
                                    placement
                                    opportunities to Deserving students.</p>
                                <p><i class="bi bi-check2"></i>It is noteworthy to point out that last 12 years we have
                                    had
                                    100% placement.
                                </p>

                            </div><!-- End Tab 1 Content -->

                            <div class="tab-pane fade show" id="tab7">

                                <ul>
                                    <li>
                                        <h4>INSTITUTE CERTIFICATE COURSE in COMPUTER-AIDED INTERIOR SPACE DESIGN &
                                            MANAGEMENT:</h4>
                                        <b>Duration: </b>Full Time - ONE YEAR (two
                                        terms)<br>
                                        <p><b>Eligibility </b> - Students passing the SECONDARY
                                            SCHOOL CERTIFICATE BOARD EXAMINATION of Maharashtra or equivalent and
                                            passing the <span style="margin-left: 8%;">APTITUDE
                                                TEST
                                                conducted by the Institute.</span>
                                        </p>

                                    </li>

                                    <li>
                                        <p>
                                        <h4> INSTITUTE DIPLOMA COURSE in COMPUTER-AIDED INTERIOR SPACE DESIGN &
                                            MANAGEMENT</h4>
                                        <b>Duration: </b>Full Time - TWO YEAR (four terms)<br>
                                        <b>Eligibility </b> -Students passing the SECONDARY SCHOOL CERTIFICATE BOARD
                                        EXAMINATION of
                                        Maharashtra or equivalent (students passed with <span style="margin-left: 7%;">
                                            Technical
                                            subjects or Drawing Grade Examination
                                            could be given preference) and passing the APTITUDE TEST conducted by
                                            the</span>
                                        <span style="margin-left: 7%;">Institute.</span>
                                        </p>
                                    </li>
                                </ul>

                            </div><!-- End Tab 1 Content -->

                            <div class="tab-pane fade show" id="tab8">

                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p>FEES ONCE PAID, WILL NOT BE REFUNDED. </p>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p>The Institute/Department has the right to refuse admission without assigning any
                                        reason. </p>
                                </div>


                            </div><!-- End Tab 1 Content -->


                        </div>

                    </div>

                    <!--  <div class="col-lg-6">
            <img src="assets/img/features-2.png" class="img-fluid" alt="">
          </div> -->

                </div><!-- End Feature Tabs -->



            </div>

        </section><!-- End Features Section -->





        <!-- ======= Features Section ======= -->
        <section id="structure" class="features">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <h2 style="margin-bottom: 10px;">CERTIFICATE AND DIPLOMA COURSES </h2>
                    <span>STRUCTURE OF THE CERTIFICATE AND DIPLOMA COURSES</span>

                </header>
                <!-- Feature Tabs -->
                <div class="row feture-tabs" data-aos="fade-up">
                    <div class="col-lg-12">
                        <!-- <h3>STRUCTURE OF THE CERTIFICATE AND DIPLOMA COURSES</h3> -->

                        <!-- Tabs -->
                        <ul class="nav nav-pills mb-3">
                            <li>
                                <a class="nav-link active" data-bs-toggle="pill" href="#tab11">CURRICULUM- FULL TIME
                                    COURSE</a>
                            </li>
                            <li><a class="nav-link " data-bs-toggle="pill" href="#tab21">SYLLABUS & SUBJECT SUMMERY </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab31">ACADEMIC FACILITIES </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab41">EXAMINATIONS </a>
                            </li>
                            <li>
                                <a class="nav-link" data-bs-toggle="pill" href="#tab51">STANDARD OF PASSING</a>
                            </li>
                        </ul><!-- End Tabs -->

                        <!-- Tab Content -->
                        <div class="tab-content">

                            <div class="tab-pane fade show active" id="tab11">

                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p>The total number of credits to be completed at the end of the SECOND YEAR (four
                                        terms) will be a minimum of 60.</p>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p> One credit will be 25 marks. </p>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p> One period of 45 minutes of Theory per week per term.</p>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p> Two/Three/Four periods accounting for 90/135/180 minutes of one Practical
                                        (studio) per term.</p>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p> Each term will have 16 weeks and each week will have a minimum of 22 hours of
                                        teaching accounting for 1408 hours in four terms of two-year full-time duration.
                                    </p>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-check2"></i>
                                    <p> An internship of 3 months (90days) has 150 marks (6 credits), not included in
                                        above.
                                    </p>
                                </div>

                            </div><!-- End Tab 1 Content -->

                            <div class="tab-pane fade show" id="tab21">
                                <p>The syllabus of these courses is specially designed to shape individuals into
                                    SUCCESSFUL, NOBLE & PRACTICAL INTERIOR DESIGNERS and ABLE PROFESSIONAL MANAGERS.
                                    This is a comprehensive program, which encompasses various aspects of Interior
                                    Designing.</p>
                                <div class="d-flex align-items-center mb-2">

                                    <span><b>i. </b> First year (full-time) covers the fundamentals in Drawing, Drafting
                                        & Designing with ERGONOMICAL CONSIDERATION, the Residential Interior Spaces
                                        along with an understanding of the structure system and its importance while
                                        designing.</span>
                                </div>

                                <div class="d-flex align-items-center mb-2">

                                    <span><b>ii.</b> INSTITUTE DIPLOMA COURSE in COMPUTER-AIDED INTERIOR SPACE DESIGN &
                                        MANAGEMENT (Two-year full-time).
                                    </span>
                                </div>
                                <b>Subject Summary of the above-mentioned Courses: </b>
                                <p>1. CERTIFICATE course in Computer Aided Interior Space Design & Management. (ONE YEAR
                                    full-time)
                                <ul>
                                    <li>THEORY OF DESIGN (Th)</li>
                                    <li> THEORY OF MATERIALS I/II (Th)</li>
                                    <li> DRAWING AND PERSPECTIVE (Pr)</li>
                                    <li> WORKING DRAWING- I (Pr)</li>
                                    <li>SERVICES - I (Th)</li>
                                    <li>ART OF RENDERING (Pr)</li>
                                    <li>MODEL MAKING (Pr)</li>
                                    <li>RESIDENTIAL INTERIOR SPACE DESIGN (Pr)</li>
                                    <li> COMPUTER-AIDED DRAWING & DRAFTING </li>
                                </ul>
                                </p>
                                <p>2. DIPLOMA course in Computer Aided Interior Space Design & Management.
                                    (TWO YEAR full time) In addition to 1st year subjects the under listed subjects:-
                                <ul>
                                    <li> PROFESSIONAL MANAGEMENT (Th)</li>
                                    <li> SERVICES - II (Th)</li>
                                    <li> SEMINAR (Pr)</li>
                                    <li> COMMERCIAL INTERIOR SPACE DESIGN (Th/Pr)</li>
                                    <li> WORKING DRAWING - II (Pr)</li>
                                    <li> COMPUTER AIDED DESIGNING & DETAILING (Pr)</li>
                                    <li> INDEPTH/ PROJECT STUDY (Pr)</li>
                                    <li> INTERNSHIP </li>
                                </ul>
                                </p>

                            </div><!-- End Tab 2 Content -->

                            <div class="tab-pane fade show" id="tab31">
                                <p> <b>LIBRARY:</b>
                                    More than 1000 titles are acquired & more than 10 journals have been subscribed-
                                    Among reference books, many of them are by foreign authors.
                                    The Institute has an “e-design computer center” having 120 computers available along
                                    with relevant software to impart Computer Education to Diploma in Computer Aided
                                    Interior Space Design & Management students.</p>
                                <p><b>LIBRARY DEPOSIT:</b> Students desirous of having a home reading of Library Books
                                    for reference, shall pay RS 1000/-(or more depending upon the price of books) as
                                    LIBRARY DEPOSIT (refundable).</p>


                            </div><!-- End Tab 3 Content -->

                            <div class="tab-pane fade show" id="tab41">


                                <p>Annual Examinations/ Supplementary Examination of the course will be held by the
                                    respective department of the Institute of Design. Only those, who submit the
                                    complete required term work to the satisfaction of the HOD/In charge faculties, will
                                    be eligible to appear for the annual examination besides fulfilling the condition of
                                    attendance i.e. 75% of the total working days of the course per year.<br>
                                    The amount of the Examinations Fee will be announced approximately a month before
                                    examinations are held.
                                </p>

                            </div><!-- End Tab 1 Content -->


                            <div class="tab-pane fade show" id="tab51">

                                <p>To successfully complete the Program, the Candidate must obtain a minimum of 45% of
                                    each of the internal and external marks respectively assigned to each subject and
                                    paper subject of the course. Candidates successfully completing the program will be
                                    awarded respective CERTIFICATE / DIPLOMA by the Institute.
                                </p>

                            </div><!-- End Tab 1 Content -->



                        </div>

                    </div>

                    <!--   <div class="col-lg-6">
            <img src="assets/img/features-2.png" class="img-fluid" alt="">
          </div> -->

                </div><!-- End Feature Tabs -->



            </div>

        </section>
        <!-- End Features Section -->






        <!-- ======= Team Section ======= -->
        <section id="team" class="team">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <!-- <h2>Team</h2> -->
                    <h2>Our hard working team</h2>
                </header>

                <div class="row" style="margin-top: 3%;">
                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="100">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/pratiksha.PNG" class="img-fluid" alt="">
                            </div>
                            <div class="member-info">
                                <h4>Pratiksha Raval </h4>
                                <span>H.O.D</span>
                                <span>Professional Experience : 33yrs </span>
                                <span>Teaching Experience : 27yrs</span>

                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="200">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/tripti.jpg" class="img-fluid" alt=""
                                    style="width: 245px;height: 305px;">

                            </div>
                            <div class="member-info">
                                <h4>Trupti Shah</h4>
                                <span>Professional Experience : 25yrs </span>
                                <span>Teaching Experience : 18yrs</span>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="200">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/shanmu.jpg" class="img-fluid" alt="">

                            </div>
                            <div class="member-info">
                                <h4>Shanmughdas Madhavan k. K</h4>
                                <span>Professional Experience : 23yrs </span>
                                <span>Teaching Experience : 21yrs</span>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="300">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/sachine.jpg" class="img-fluid" alt="sachine"
                                    style="width: 245px;height: 305px;">

                            </div>
                            <div class="member-info">
                                <h4>Sachin Jagtap</h4>
                                <span>Professional Experience : 23yrs </span>
                                <span>Teaching Experience : 20yrs</span>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="400">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/ravi.jpg" class="img-fluid" alt="ravi">

                            </div>
                            <div class="member-info">
                                <h4>Ravi Chauhan</h4>
                                <span>Professional Experience : 20yrs </span>
                                <span>Teaching Experience : 10yrs</span>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="400">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/abhishek.jpg" class="img-fluid" alt="abhishek"
                                    style="width: 245px;height: 305px;">

                            </div>
                            <div class="member-info">
                                <h4>Abhishek Parab</h4>
                                <span>Professional Experience : 15yrs </span>
                                <span>Teaching Experience : 8yrs</span>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="400">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/prajakta.jpg" class="img-fluid" alt="">

                            </div>
                            <div class="member-info">
                                <h4>Prajakta Joijode</h4>
                                <span>Professional Experience : 10yrs </span>
                                <span>Teaching Experience : 8yrs</span>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-xs-12  align-items-stretch" data-aos="fade-up"
                        data-aos-delay="400">
                        <div class="member">
                            <div class="member-img">
                                <img src="assets/img/team/rupak.jpg" class="img-fluid" alt="rupak"
                                    style="width: 245px;height: 305px;">

                            </div>
                            <div class="member-info">
                                <h4>Rupak Shah</h4>
                                <span>Teaching Experience : 10yrs</span>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </section><!-- End Team Section -->


        <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact">
            <div class="container" data-aos="fade-up">
                <header class="section-header">
                    <p class="mb-3">Contact Us</p>
                </header>
                <div class="row " style="padding: 20px 0px;">
                    <div class="col-lg-6">
                        <div class="row gy-4">
                            <div class="col-lg-12 col-md-12 col-xs-12">
                                <div class="info-box">
                                    <i class="bi bi-geo-alt"></i>
                                    <h3>Address</h3>
                                    <p><a href="https://goo.gl/maps/9P9vkwkVfEJrzvhm7" target="_blank"
                                            style="color:black;">
                                            School of Design
                                            Next to New English School, Near Kherwadi Police Station
                                            Goverment coloy Bandra East, Mumbai-51</a></p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-xs-12">
                                <div class="info-box">
                                    <i class="bi bi-telephone"></i>
                                    <h3>Call Us</h3>
                                    <p type="tel"><a href="tel:8849403077" type="phone" style="color:black;"
                                            target="_blank">8849403077</a> / <a href="tel:9702699533" type="phone"
                                            style="color:black;" target="_blank">9702699533</a> / <a
                                            href="tel: 022-31621953" type="phone" style="color:black; " target="_blank">
                                            022-31621953</a></p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-xs-12 mail-box">
                                <div class="info-box">
                                    <i class="bi bi-envelope"></i>
                                    <h3>Email Us</h3>
                                    <p type="email"><a href="mailto:hiraycaisdm@gmail.com"
                                            style="color:black;">hiraycaisdm@gmail.com</a></p>
                                </div>
                            </div>
                            <!-- <div class="col-md-6">
                <div class="info-box">
                  <i class="bi bi-clock"></i>
                  <h3>Open Hours</h3>
                  <p>Monday - Friday<br>9:00AM - 05:00PM</p>
                </div>
              </div> -->
                        </div>

                    </div>

                    <div class="col-lg-6">
                        <?php if (isset($error)) { ?>
                        <!-- <div class="alert alert-danger message">
                            <?php // echo $errorMessage; 
                            ?>
                        </div> -->
                        <?php } ?>
                        <?php if (isset($success)) { ?>
                        <script>
                        alert('Thank you for your Message, We will get back to you');
                        </script>
                        <?php } ?>
                        <form action="" method="post" class="form-class">
                            <div class="row gy-4">
                                <div class="col-md-6">
                                    <input type="text" name="name" class="form-control" placeholder="Your Name"
                                        required>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="email" class="form-control" name="email" placeholder="Your Email"
                                        required>
                                </div>

                                <div class="col-md-12">
                                    <input type="text" class="form-control" name="subject" placeholder="Subject"
                                        required>
                                </div>

                                <div class="col-md-12">
                                    <textarea class="form-control" name="message" rows="6" placeholder="Message"
                                        required></textarea>
                                </div>

                                <div class="col-md-12 text-center">
                                    <!-- <div class="loading">Loading</div>
                                    <div class="error-message"></div>
                                    <div class="sent-message">Your message has been sent. Thank you!</div>
                                    <button type="submit" id="send" name="send_msg">Send Message</button> -->
                                </div>
                                <!-- <button type="submit" id="send" name="send_msg">Send Message</button> -->
                                <div class="text-center"><button type="submit" id="send" name="send_msg">Send
                                        Message</button></div>

                            </div>
                        </form>

                    </div>

                </div>

            </div>

        </section><!-- End Contact Section -->

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row gy-4">
                    <!-- <div class="col-lg-5 col-md-12 footer-info">
                        <a href="index.php" class="logo d-flex align-items-center">
                            <span>HIRAY COLLEGE</span>
                        </a>
                        <div class="social-links mt-5" style="margin: 0px 10%;">
                            <a href="https://twitter.com/" target="_blank" class="twitter"><i
                                    class="bi bi-twitter"></i></a>
                            <a href="https://www.facebook.com/hiray.architecture" class="facebook" target="_blank"><i
                                    class="bi bi-facebook"></i></a>

                            <a href="https://www.linkedin.com/in/hiray-placement-and-alumni-cell-16b879233/"
                                class="linkedin" target="_blank"><i class="bi bi-linkedin"></i></a>
                        </div>
                    </div> -->

                    <div class="col-lg-2 col-md-2 col-xs-12 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                            <li><i class="bi bi-chevron-right"></i> <a href="#hero">Home</a></li>
                            <li><i class="bi bi-chevron-right"></i> <a href="#about">About us</a></li>
                            <li><i class="bi bi-chevron-right"></i> <a href="#courses">Courses</a></li>
                            <li><i class="bi bi-chevron-right"></i> <a href="#structure">Structure of courses</a></li>
                            <li><i class="bi bi-chevron-right"></i> <a href="#team">Teams</a></li>
                            <li><i class="bi bi-chevron-right"></i> <a href="#contact">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-7 col-md-7 col-xs-12 text-center">
                        <iframe class="map-design"
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15083.75212588787!2d72.8493439!3d19.066462!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c91dc7b91b81%3A0x64de056561407522!2sHiray%20College!5e0!3m2!1sen!2sin!4v1689945930277!5m2!1sen!2sin"
                            style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="col-lg-3 col-md-3 col-xs-12 footer-contact text-center text-md-start">
                        <h4>Contact Us</h4>
                        <strong>Address:</strong>
                        <p>
                            <a href="https://goo.gl/maps/9P9vkwkVfEJrzvhm7" target="_blank" style="color:black;"> Next
                                to New English School, Near Kherwadi Police Station
                                Goverment coloy Bandra East, Mumbai-51</a><br>
                            <strong>Phone:</strong> <a href="tel:8849403077" type="phone" style="color:black;"
                                target="_blank">8849403077</a> / <a href="tel:9702699533" type="phone"
                                style="color:black;" target="_blank">9702699533</a> / <a class="ladline"
                                href="tel: 022-31621953" type="phone" style="color:black;" target="_blank">
                                022-31621953</a> <br>
                            <strong>Email:</strong><a href="mailto:hiraycaisdm@gmail.com"
                                style="color:black;">hiraycaisdm@gmail.com</a><br>
                        </p>

                        <div class="social-links mt-5" style="margin: 0px 10%;">
                            <a href="https://twitter.com/" target="_blank" class="twitter"><i
                                    class="bi bi-twitter"></i></a>
                            <a href="https://www.facebook.com/hiray.architecture" class="facebook" target="_blank"><i
                                    class="bi bi-facebook"></i></a>

                            <a href="https://www.linkedin.com/in/hiray-placement-and-alumni-cell-16b879233/"
                                class="linkedin" target="_blank"><i class="bi bi-linkedin"></i></a>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="container">
            <div class="copyright">
                &copy; Copyright 2023 <strong><span><a href="index.php">HIRAY COLLEGE</a></span></strong>. All Rights
                Reserved
            </div>
            <div class="credits">
                <!-- All the links in the footer should remain intact. -->
                <!-- You can delete the links only if you purchased the pro version. -->
                <!-- Licensing information: https://bootstrapmade.com/license/ -->
                <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/flexstart-bootstrap-startup-template/ -->
                Designed by <a href="https://kubictechnology.com/" target="_blank">Kubic Technology</a>
            </div>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
    <script>
    // $(document).ready(function() {
    //     $('.message').hide();
    //     $("#send").on('click', function() {
    //         $('.message').show();
    //     });
    // })
    </script>

</body>

</html>